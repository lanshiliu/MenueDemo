//
//  MyTableViewCell.m
//  MenueDemo
//
//  Created by liubo on 16/5/27.
//  Copyright © 2016年 liubo. All rights reserved.
//

#import "MyTableViewCell.h"
#import "LBMenue.h"

@interface MyTableViewCell()<LBMenueDelegate>
{
    LBMenue *_lbMenue;
}
@end

@implementation MyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _lbMenue = [[LBMenue alloc] initWithSuperView:self.contentView andDirection:LBMenueDirectionLeft point:CGPointMake(20, 100)];
    _lbMenue.menueDelegate = self;
    [_lbMenue lbmenueReloadData];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark - LBMenueDelegate
- (CGFloat)heightForLBMenue
{
    return 50;
}

- (NSInteger)countForLBMenueItems
{
    return 4;
}
- (CGFloat)spaceForLBMenue
{
    return 10;
}

- (UIColor *)lbmenueBackgroundColor
{
    UIColor *backColor = [UIColor redColor];
    return backColor;
}

- (UIButton *)buttonForLBMenueWithIndex:(NSInteger)index
{
    UIButton *menueItem = [UIButton buttonWithType:UIButtonTypeCustom];
    [menueItem setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%ld.png",index + 1]] forState:UIControlStateNormal];
    return menueItem;
}
- (UIImage *)imageForHomeButtonCloseState
{
    UIImage *close = [UIImage imageNamed:@"close.png"];
    return close;
}
- (UIImage *)imageForHomeButtonOpenState
{
    UIImage *open = [UIImage imageNamed:@"open.png"];
    return open;
}
- (void)lbmenueDidSelectedItemWithIndex:(NSInteger)index
{
    
}

@end
