//
//  MainViewController.m
//  MenueDemo
//
//  Created by liubo on 16/5/23.
//  Copyright © 2016年 liubo. All rights reserved.
//

#import "MainViewController.h"
#import "LBMenue.h"
#import "MyTableViewController.h"

@interface MainViewController ()<LBMenueDelegate>
{
    LBMenue *_lbMenue;
}
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _lbMenue = [[LBMenue alloc] initWithSuperView:self.view andDirection:LBMenueDirectionLeft point:CGPointMake(20, 100)];
    _lbMenue.menueDelegate = self;
    [_lbMenue lbmenueReloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - LBMenueDelegate
- (CGFloat)heightForLBMenue
{
    return 50;
}

- (NSInteger)countForLBMenueItems
{
    return 4;
}
- (CGFloat)spaceForLBMenue
{
    return 10;
}

- (UIColor *)lbmenueBackgroundColor
{
    UIColor *backColor = [UIColor redColor];
    return backColor;
}

- (UIButton *)buttonForLBMenueWithIndex:(NSInteger)index
{
    UIButton *menueItem = [UIButton buttonWithType:UIButtonTypeCustom];
    [menueItem setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%ld.png",index + 1]] forState:UIControlStateNormal];
    return menueItem;
}
- (UIImage *)imageForHomeButtonCloseState
{
    UIImage *close = [UIImage imageNamed:@"close.png"];
    return close;
}
- (UIImage *)imageForHomeButtonOpenState
{
    UIImage *open = [UIImage imageNamed:@"open.png"];
    return open;
}
- (void)lbmenueDidSelectedItemWithIndex:(NSInteger)index
{
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)gotoTableview:(id)sender {
    MyTableViewController *tableVc = [[MyTableViewController alloc] initWithNibName:@"MyTableViewController" bundle:nil];
    [self.navigationController pushViewController:tableVc animated:YES];
}
@end
