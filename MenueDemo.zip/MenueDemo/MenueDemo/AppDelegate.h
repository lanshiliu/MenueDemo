//
//  AppDelegate.h
//  MenueDemo
//
//  Created by liubo on 16/5/23.
//  Copyright © 2016年 liubo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MainViewController * viewController;

@end

