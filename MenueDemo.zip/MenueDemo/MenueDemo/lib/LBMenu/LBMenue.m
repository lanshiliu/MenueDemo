//
//  LBMenue.m
//  MenueDemo
//
//  Created by liubo on 16/5/23.
//  Copyright © 2016年 liubo. All rights reserved.
//

#define kItemBaseTag 10000
#define kAnimationTime 0.3

#import "LBMenue.h"
#import <QuartzCore/QuartzCore.h>

@interface LBMenue()
{
    UIView *_superView;
    LBMenueDirection _derection;
    CGPoint _point;
    NSMutableArray *_menueItems;
    BOOL _isOpen;
    UIButton *_closeStateBtn;
    UIButton *_openStateBtn;
    CGFloat _space;
}
@end

@implementation LBMenue

- (instancetype)initWithSuperView:(UIView *)superView andDirection:(LBMenueDirection)derection point:(CGPoint)point
{
    self = [super init];
    if (self) {
        _superView = superView;
        _derection = derection;
        _point = point;
    }
    return self;
}
- (void)lbmenueReloadData
{
    [self addItems];
    
    
}

- (void)addItems
{
    CGFloat viewHeight = 0;
    if ([self.menueDelegate respondsToSelector:@selector(heightForLBMenue)]) {
        viewHeight = [self.menueDelegate heightForLBMenue];
    }
    
    NSInteger itemCount = 0;
    if ([self.menueDelegate respondsToSelector:@selector(countForLBMenueItems)]) {
        itemCount = [self.menueDelegate countForLBMenueItems];
    }
    
    CGFloat space = 0;
    if ([self.menueDelegate respondsToSelector:@selector(spaceForLBMenue)]) {
        space = [self.menueDelegate spaceForLBMenue];
    }
    _space = space;
    
    CGFloat viewWidth = (viewHeight + space) * itemCount + viewHeight;
    
    self.frame = CGRectMake(_point.x, _point.y, viewWidth, viewHeight);
    UIColor *backColor = nil;
    if ([self.menueDelegate respondsToSelector:@selector(lbmenueBackgroundColor)]) {
        backColor = [self.menueDelegate lbmenueBackgroundColor];
    } else {
        backColor = _superView.backgroundColor;
    }
    self.backgroundColor = backColor;
    [_superView addSubview:self];
    
    if ([self.menueDelegate respondsToSelector:@selector(buttonForLBMenueWithIndex:)]) {
        _menueItems = [NSMutableArray array];
        for (int i = 0; i < itemCount; i++) {
            UIButton *itemBtn = [self.menueDelegate buttonForLBMenueWithIndex:i];
            CGFloat itemX = 0;
            if (_derection == LBMenueDirectionLeft) {
                itemX = self.frame.size.width - viewHeight - (viewHeight + _space) * (i + 1);
            } else {
                itemX = (viewHeight + _space) * (i + 1);
                
            }
            itemBtn.alpha = 0;
            itemBtn.frame = CGRectMake(itemX, 0, viewHeight, viewHeight);
            itemBtn.tag = kItemBaseTag + i;
            [self addSubview:itemBtn];
            [_menueItems addObject:itemBtn];
            [itemBtn addTarget:self action:@selector(itemButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    
    UIImage *closeState = nil;
    if ([self.menueDelegate respondsToSelector:@selector(imageForHomeButtonCloseState)]) {
        closeState = [self.menueDelegate imageForHomeButtonCloseState];
    }
    
    UIImage *openState = nil;
    if ([self.menueDelegate respondsToSelector:@selector(imageForHomeButtonOpenState)]) {
        openState = [self.menueDelegate imageForHomeButtonOpenState];
    }
    
    if (closeState) {
        _closeStateBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_closeStateBtn setImage:closeState forState:UIControlStateNormal];
        CGFloat itemX = 0;
        if (_derection == LBMenueDirectionLeft) {
            itemX = self.frame.size.width - viewHeight;
        } else {
            itemX = 0;
        }
        _closeStateBtn.frame = CGRectMake(itemX, 0, viewHeight, viewHeight);
        [self addSubview:_closeStateBtn];
        [_closeStateBtn addTarget:self action:@selector(homeButtonClick) forControlEvents:UIControlEventTouchUpInside];
    }
    
    if (openState) {
        _openStateBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_openStateBtn setImage:openState forState:UIControlStateNormal];
        CGFloat itemX = 0;
        if (_derection == LBMenueDirectionLeft) {
            itemX = self.frame.size.width - viewHeight;
        } else {
            itemX = 0;
        }
        _openStateBtn.frame = CGRectMake(itemX, 0, viewHeight, viewHeight);
        [self addSubview:_openStateBtn];
        [_openStateBtn addTarget:self action:@selector(homeButtonClick) forControlEvents:UIControlEventTouchUpInside];
        _openStateBtn.alpha = 0;
    }
    
    _isOpen = NO;
}

#pragma mark - action
- (void)itemButtonClick:(UIButton *)itemBtn
{
    if ([self.menueDelegate respondsToSelector:@selector(lbmenueDidSelectedItemWithIndex:)]) {
        NSInteger index = itemBtn.tag - kItemBaseTag;
        [self.menueDelegate lbmenueDidSelectedItemWithIndex:index];
        NSLog(@"您选择了第--%ld--个按钮",(long)index);
    }
}

- (void)homeButtonClick
{
    CGFloat viewHeight = self.frame.size.height;//item的宽度就是view的高度
    if (_isOpen) {//菜单打开状态
        CGFloat itemX = 0;
        
        if (_derection == LBMenueDirectionLeft) {
            itemX = self.frame.size.width - viewHeight;
        } else {
            itemX = 0;
        }
        for (int i = 0; i < _menueItems.count; i++) {
            UIButton *itemBtn = _menueItems[i];
            [UIView animateWithDuration:kAnimationTime delay:0 usingSpringWithDamping:0.5 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                itemBtn.alpha = 0;
             } completion:^(BOOL finished) {
                 _isOpen = NO;
             }];
            
            CGFloat x = itemBtn.frame.origin.x;
            CGFloat y = itemBtn.frame.origin.y;
            
            CGFloat endX = -x;
            CGFloat endY = y;
            
            CAKeyframeAnimation *positionAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation"];
            positionAnimation.fillMode = kCAFillModeForwards;
            positionAnimation.removedOnCompletion = NO;

            [positionAnimation setDuration:kAnimationTime];
            CGMutablePathRef path = CGPathCreateMutable();
            CGPathMoveToPoint(path, NULL, x, y);
            CGPathAddLineToPoint(path, NULL, endX, endY);
            [positionAnimation setPath: path];
            CGPathRelease(path);
            
            [itemBtn.layer addAnimation:positionAnimation forKey:nil];
            
            
            
            
            
        }
    } else {//菜单关闭状态
        for (int i = 0; i < _menueItems.count; i++) {
            CGFloat itemX = 0;
            
            CGFloat x = 0;
            CGFloat y = 0;
            if (_derection == LBMenueDirectionLeft) {
                itemX = self.frame.size.width - viewHeight - (viewHeight + _space) * (i + 1);
                x = self.frame.size.width - viewHeight;
            } else {
                itemX = (viewHeight + _space) * (i + 1);
                x = 0;
            }
            UIButton *itemBtn = _menueItems[i];
            [UIView animateWithDuration:kAnimationTime delay:0 usingSpringWithDamping:0.5 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                itemBtn.alpha = 1;
            } completion:^(BOOL finished) {
                _isOpen = YES;
            }];
            
            
            
            CGFloat endX = 0;
            CGFloat endY = y;
            
            CGFloat far = 15;
            CGFloat near = 7;
            CGFloat farX = 0;
            CGFloat farY = y;
            
            CGFloat nearX = 0;
            CGFloat nearY = y;
            if (_derection == LBMenueDirectionLeft) {
                farX = endX - far;
                nearX = endX + near;
            } else {
                farX = endX + far;
                nearX = endX - near;
            }

            CAKeyframeAnimation *positionAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation"];

            positionAnimation.fillMode = kCAFillModeForwards;
            positionAnimation.removedOnCompletion = NO;
            [positionAnimation setDuration:kAnimationTime];
            
            CGMutablePathRef path = CGPathCreateMutable();
            CGPathMoveToPoint(path, NULL, x, y);
            CGPathAddLineToPoint(path, NULL, farX, farY);
            CGPathAddLineToPoint(path, NULL, nearX, nearY);
            CGPathAddLineToPoint(path, NULL, endX, endY);
            [positionAnimation setPath: path];
            CGPathRelease(path);
            [itemBtn.layer addAnimation:positionAnimation forKey:nil];
        }
    }
    
    if (_isOpen) {//菜单打开状态

        
        [UIView animateWithDuration:kAnimationTime animations:^{
            _closeStateBtn.alpha = 1;
            _openStateBtn.alpha = 0;
        } completion:^(BOOL finished) {
            
        }];
        
    } else {//菜单关闭状态

        [UIView animateWithDuration:kAnimationTime animations:^{
            _closeStateBtn.alpha = 0;
            _openStateBtn.alpha = 1;
        } completion:^(BOOL finished) {
            
        }];
    }
    
    
}

- (void)animationDidStart:(CAAnimation *)anim
{
    
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    
}


@end
