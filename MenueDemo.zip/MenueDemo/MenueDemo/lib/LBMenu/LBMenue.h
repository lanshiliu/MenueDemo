//
//  LBMenue.h
//  MenueDemo
//
//  Created by liubo on 16/5/23.
//  Copyright © 2016年 liubo. All rights reserved.
//



#import <UIKit/UIKit.h>

typedef enum {
    LBMenueDirectionLeft,//向左边打开
    LBMenueDirectionRight//向右边打开
} LBMenueDirection;

@protocol LBMenueDelegate <NSObject>
- (UIColor *)lbmenueBackgroundColor;
@required
- (CGFloat)heightForLBMenue;//菜单的高度
- (NSInteger)countForLBMenueItems;//菜单的个数，不包括开关按钮
- (CGFloat)spaceForLBMenue;//菜单之间的空隙
- (UIButton *)buttonForLBMenueWithIndex:(NSInteger)index;//菜单按钮
- (UIImage *)imageForHomeButtonCloseState;//开关按钮关闭状态的图片
- (UIImage *)imageForHomeButtonOpenState;//开关按钮开启状态的图片
- (void)lbmenueDidSelectedItemWithIndex:(NSInteger)index;//点击菜单的回调
@end



@interface LBMenue : UIView
- (instancetype)initWithSuperView:(UIView *)superView andDirection:(LBMenueDirection)derection point:(CGPoint)point;
- (void)lbmenueReloadData;
@property (nonatomic, assign) id<LBMenueDelegate> menueDelegate;
@end
