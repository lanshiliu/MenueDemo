//
//  MainViewController.h
//  MenueDemo
//
//  Created by liubo on 16/5/23.
//  Copyright © 2016年 liubo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController
- (IBAction)gotoTableview:(id)sender;

@end
