//
//  MyTableViewCell.h
//  MenueDemo
//
//  Created by liubo on 16/5/27.
//  Copyright © 2016年 liubo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewCell : UITableViewCell

@end
